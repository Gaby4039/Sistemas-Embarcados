#ifndef SM1_H
#define SM1_H

#include "sm.h"

//Declaração dos estados da máquina1
STATE(sm1_init);
STATE(sm1_v1_ligada);
STATE(sm1_v1_desligada);
STATE(sm1_erro);
const char* sm1_state_str;

#endif // SM1_H
