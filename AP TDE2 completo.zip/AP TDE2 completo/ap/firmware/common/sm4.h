#ifndef SM4_H
#define SM4_H

#include "sm.h"

//Declaração das funções da máquina 2
STATE(sm4_init);
STATE(sm4_r1_ligada);
STATE(sm4_r1_desligada);
STATE(sm4_erro);
const char* sm4_state_str;

#endif // SM2_H
