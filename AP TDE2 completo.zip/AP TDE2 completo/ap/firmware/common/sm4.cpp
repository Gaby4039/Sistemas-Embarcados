#include "../common/sm4.h"
#include "../common/hal.h"
#include "../common/definitions.h"
#include "../common/chronometer.h"

STATE(sm4_init) {
    if(ENTRY) {
        set_r1(false);
        set_sm4_error(false);
        sm4_state_str = "sm4_init";
    }

    if(!get_s31()) {
        NEXT_STATE(sm4_r1_desligada);
    }
    else if(get_st1() <= 49.0) {
        NEXT_STATE(sm4_r1_ligada);
    }
    else {
        NEXT_STATE(sm4_r1_desligada);
    }
}
STATE(sm4_r1_ligada) {
    if(ENTRY) {
        set_r1(true);
        sm4_state_str = "sm4_r1_ligada";
    }

    if(get_st1() >= 51.0 || !get_s31()) {
        NEXT_STATE(sm4_r1_desligada);
    }
}

STATE(sm4_r1_desligada) {
    if(ENTRY) {
        set_r1(false);
        sm4_state_str = "sm4_r1_desligada";
    }

    if(get_s31()) {
        if(get_st1() <= 49.0) {
            NEXT_STATE(sm4_r1_ligada);
        }
    }
}
