#include "../common/sm2.h"
#include "../common/hal.h"
#include "../common/definitions.h"
#include "../common/chronometer.h"

chronometer sm2_chrono;

STATE(sm2_init){
    if(ENTRY){
        set_b1(false);
        set_sm2_error(false);
        sm2_state_str = "sm2_init";
    }

    if(get_s11()) {
        if(!get_s22) {
            NEXT_STATE(sm2_b1_ligada);
        }
    }
    else {
        NEXT_STATE(sm2_b1_desligada);
    }

    if(get_s22()){
        if(get_s21()){
            NEXT_STATE(sm2_b1_desligada);
        } else {
            NEXT_STATE(sm2_erro);
        }
    }
}

STATE(sm2_b1_ligada){
    if(ENTRY){
        set_b1(true);
        set_sm2_error(false);
        sm2_state_str = "sm2_b1_ligada";
    }

    if(!get_s11()) {
        NEXT_STATE(sm2_b1_desligada);
    }
    else {
        if(get_s22()){
            if(get_s21()){
                NEXT_STATE(sm2_b1_desligada);
            } else{
                NEXT_STATE(sm2_erro);
            }
        }
    }
}

STATE(sm2_b1_desligada){
    if(ENTRY){
        set_b1(false);
        set_sm2_error(false);
        chrono_start(&sm2_chrono, SM2_TIMER);
        sm2_state_str = "sm2_b1_desligada";
    }

    if(get_s22()){
        if(!get_s21()){
            NEXT_STATE(sm2_erro);
        }
    }

    else {
        if(chrono_is_finished(&sm2_chrono)){
            NEXT_STATE(sm2_b1_ligada);
        }
    }
}

STATE(sm2_erro){
    if(ENTRY){
        set_b1(false);
        set_sm2_error(true);
        sm2_state_str = "sm2_erro";
    }
}
