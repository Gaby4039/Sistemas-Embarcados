behavior.d behavior.o: ../../../common/behavior.cpp \
 ../../../common/behavior.h ../../../common/hal.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h \
 ../../../common/sm1.h ../../../common/sm.h ../../../common/sm2.h \
 ../../../common/sm3.h ../../../common/sm4.h

../../../common/behavior.h:

../../../common/hal.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h:

../../../common/sm1.h:

../../../common/sm.h:

../../../common/sm2.h:

../../../common/sm3.h:

../../../common/sm4.h:
