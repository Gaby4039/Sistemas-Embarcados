sm4.d sm4.o: ../../../common/sm4.cpp ../../../common/../common/sm4.h \
 ../../../common/../common/sm.h ../../../common/../common/hal.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h \
 ../../../common/../common/definitions.h \
 ../../../common/../common/chronometer.h

../../../common/../common/sm4.h:

../../../common/../common/sm.h:

../../../common/../common/hal.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h:

../../../common/../common/definitions.h:

../../../common/../common/chronometer.h:
