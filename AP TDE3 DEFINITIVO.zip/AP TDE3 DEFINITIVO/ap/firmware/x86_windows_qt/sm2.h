#ifndef SM2_H
#define SM2_H

#include "sm.h"



#endif // SM2_H


STATE(sm1_init);
STATE(sm1_v1_ligada);
STATE(sm1_v1_desligada);
STATE(sm1_erro);

#endif // SM1_H
