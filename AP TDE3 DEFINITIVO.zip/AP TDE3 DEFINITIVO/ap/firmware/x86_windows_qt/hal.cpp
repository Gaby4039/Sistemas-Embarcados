#include "../common/hal.h"
#include<time.h>

// Define o estado dos pinos
bool pin_s11 = false;
bool pin_s12 = false;
bool pin_v1 = false;
bool pin_sm1_error= false;
bool pin_s21 = false;
bool pin_s22 = false;
bool pin_b1 = false;
bool pin_sm2_error = false;
bool pin_v2 = false;
bool pin_s31 = false;
bool pin_s32 = false;
bool pin_r1 = false;
bool pin_sm3_error = false;
bool pin_sm4_error = false;
float pin_st1 = 25.0;


//Inicializa o hal
void init_hal(){
    pin_s11 = false;
    pin_s12 = false;
    pin_v1 = false;
    pin_s21 = false;
    pin_s22 = false;
    pin_b1 = false;
    pin_v2 = false;
    pin_s31 = false;
    pin_s32 = false;
    pin_r1 = false;
    pin_st1 = 25.0;
}

//Retorna a hora atual
uint32_t now(){
    return clock();
}

//Lê o pino do sensor s11
bool get_s11(){
    return pin_s11;
}

//Lê o pino do sensor s12
bool get_s12(){
    return pin_s12;
}

//Verifica o estado da válvula
void set_v1(bool state){
    pin_v1 = state;
}

//Verifica erro
void set_sm1_error(bool state){
    pin_sm1_error = state;
}

// Lê o pino do sensor s21
bool get_s21() {
    return pin_s21;
}

// Lê o pino do sensor s22
bool get_s22() {
    return pin_s22;
}

//Verifica o estado da bomba
void set_b1(bool state) {
    pin_b1 = state;
}

void set_sm2_error(bool state) {
    pin_sm2_error = state;
}

bool get_s31() {
    return pin_s31;
}

bool get_s32() {
    return pin_s32;
}

void set_v2(bool state) {
    pin_v2 = state;
}

void set_r1(bool state) {
    pin_r1 = state;
}

float get_st1() {
    return pin_st1;
}

void set_sm3_error(bool state) {
    pin_sm3_error = state;
}

void set_sm4_error(bool state) {
    pin_sm4_error = state;
}





