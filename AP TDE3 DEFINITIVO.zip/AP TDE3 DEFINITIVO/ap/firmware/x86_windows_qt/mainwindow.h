#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTimer>
#include "threadbehavior.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    QTimer update_ui_timer;
    QTimer physical_behavior_timer;

private:
    Ui::MainWindow *ui;
    ThreadBehavior thread_behavior;

public slots:
    void update_ui();
    void physical_behavior();
};
#endif // MAINWINDOW_H
