#include "../common/sm2.h"

STATE(sm2_init) {

}

STATE(sm2_bomb_ligada){

}

STATE(sm2_bomb_desligada) {

}

STATE(sm2_erro) {

}
