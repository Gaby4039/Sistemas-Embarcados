QT       += core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    ../common/behavior.cpp \
    ../common/chronometer.cpp \
    ../common/sm1.cpp \
    ../common/sm2.cpp \
    ../common/sm3.cpp \
    ../common/sm4.cpp \
    cedatank.cpp \
    hal.cpp \
    main.cpp \
    mainwindow.cpp \
    threadbehavior.cpp

HEADERS += \
    ../common/behavior.h \
    ../common/chronometer.h \
    ../common/definitions.h \
    ../common/hal.h \
    ../common/sm.h \
    ../common/sm1.h \
    ../common/sm2.h \
    ../common/sm3.h \
    ../common/sm4.h \
    cedatank.h \
    led.h \
    mainwindow.h \
    threadbehavior.h

FORMS += \
    mainwindow.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target
