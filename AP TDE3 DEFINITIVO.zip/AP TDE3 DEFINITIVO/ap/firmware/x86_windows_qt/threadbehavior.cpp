#include "threadbehavior.h"
#include "../common/behavior.h"

ThreadBehavior::ThreadBehavior() {}

void ThreadBehavior::run(){
    behavior();
}
