#ifndef HAL_H
#define HAL_H
#include<stdint.h>

//Declara a função que inicializa a camada de abstração de hardware
void init_hal();
//Inicia a contagem do tempo a partir do momento atual (armazena o tempo atual e inicia a contagem até chegar ao tempo estabelecido)
uint32_t now();
//Getters e setters para definir os pinos (leds, vávulas e bomba)
bool get_s11();
bool get_s12();
void set_v1(bool state);
bool get_s21();
bool get_s22();
void set_b1(bool state);
bool get_s31();
bool get_s32();
void set_v2(bool state);
void set_r1(bool state);
float get_st1();



//Declaração das funções de erro das máquinas de estado
void set_sm1_error(bool state);
void set_sm2_error(bool state);
void set_sm3_error(bool state);
void set_sm4_error(bool state);

#endif // HAL_H
