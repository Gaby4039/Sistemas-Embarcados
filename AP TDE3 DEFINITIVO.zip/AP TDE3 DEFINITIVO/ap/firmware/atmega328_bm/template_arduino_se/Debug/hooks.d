hooks.d hooks.o: ../../lib/arduino_core/cores/arduino/hooks.c
