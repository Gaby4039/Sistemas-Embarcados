new.d new.o: ../../lib/arduino_core/cores/arduino/new.cpp \
 ../../lib/arduino_core/cores/arduino/new.h \
 ../../lib/arduino_core/cores/arduino/new \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdlib.h \
 c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stddef.h

../../lib/arduino_core/cores/arduino/new.h:

../../lib/arduino_core/cores/arduino/new:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdlib.h:

c:\program\ files\ (x86)\atmel\studio\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stddef.h:
