#pragma once
#include<stdint.h>

//Define um cronômetro do tipo inteiro de 32 bits
typedef uint32_t chronometer;

//Declara a função que inicia a contagem do tempo em milisegundos
void chrono_start(chronometer *c, uint32_t delta_t_ms);
bool chrono_is_finished(chronometer *c);
