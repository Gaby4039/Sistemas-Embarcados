#ifndef SM2_H
#define SM2_H

#include "sm.h"

//Declaração das funções da máquina 2
STATE(sm2_init);
STATE(sm2_b1_ligada);
STATE(sm2_b1_desligada);
STATE(sm2_erro);

#endif // SM2_H
