#include"chronometer.h"
#include"hal.h"

void chrono_start(chronometer *c, uint32_t delta_t_ms) {
	*c = now() + delta_t_ms;
}

bool chrono_is_finished(chronometer *c) {
	return now() >= *c;
}