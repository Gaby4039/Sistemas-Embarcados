#ifndef BEHAVIOR_H
#define BEHAVIOR_H

//Declara a função behavior que determina o comportamento geral do projeto
void behavior();

#endif // BEHAVIOR_H
