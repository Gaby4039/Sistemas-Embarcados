#ifndef SM3_H
#define SM3_H

#include "sm.h"

//Declaração das funções da máquina 3
STATE(sm3_init);
STATE(sm3_v2_ligada);
STATE(sm3_v2_desligada);
STATE(sm3_erro);

#endif // SM3_H
