#include "behavior.h"
#include "hal.h"
#include "sm1.h"
#include "sm2.h"
#include "sm3.h"
#include "sm4.h"

//Implementação da função behavior que divide a execução em duas máquinas de estado (uma para cada tanque)
void behavior(){
    //Inicia a execução da camada de abstração de hardware
    init_hal();

    //Cria as máquinas de estado
    StateMachine sm1;
    INIT(sm1, sm1_init);
    StateMachine sm2;
    INIT(sm2, sm2_init);
    StateMachine sm3;
    INIT(sm3, sm3_init);
    StateMachine sm4;
    INIT(sm4, sm4_init);

    while(true){
        //Execut as máquinas de estado
        EXEC(sm1);
        EXEC(sm2);
        EXEC(sm3);
        EXEC(sm4);
    }

}
