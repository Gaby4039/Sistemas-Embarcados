#include "mainwindow.h"
#include "ui_mainwindow.h"

double tank1 = 0.0;
double tank2 = 0.0;

//Setup updates e threads
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(&update_ui_timer,
            &QTimer::timeout,
            this,
            &MainWindow::update_ui);
    update_ui_timer.start(33); // 3x por segundo
    connect(&physical_behavior_timer,
            &QTimer::timeout,
            this,
            &MainWindow::physical_behavior);
    physical_behavior_timer.start(10); // 100x por segundo
    thread_behavior.start();
}

MainWindow::~MainWindow()
{
    delete ui;
}

extern bool pin_v1;
extern bool pin_s11;
extern bool pin_s12;
extern bool pin_sm1_error;
extern bool pin_s21;
extern bool pin_s22;
extern bool pin_bomb;
extern bool pin_sm2_error;

void MainWindow::update_ui(){
    ui->toolButton_v1->setPower(pin_v1);
    ui->toolButton_s11->setPower(pin_s11);
    ui->toolButton_s12->setPower(pin_s12);
    ui->toolButton_sm1_error->setPower(pin_sm1_error);
    ui->toolButton_t1->setValue(tank1);
    ui->toolButton_overflow->setPower(tank1 >= 100);
    ui->toolButton_t2->setValue(tank2);
    ui->toolButton_s21->setPower(pin_s21);
    ui->toolButton_s22->setPower(pin_s22);
    ui->toolButton_bomb->setPower(pin_bomb);
    ui->toolButton_overflow_2->setPower(tank2 >= 100);
    ui->toolButton_sm2_error->setPower(pin_sm2_error);
}

void MainWindow::physical_behavior(){
    //Verifica se a válvula está ativa e adiciona 0.1 ao tanque
    if(pin_v1){
        tank1 += 0.1;
        //Verifica se a quantidade de água é maior que 100 e para no 100
        if(tank1 > 100){
            tank1 = 100;
        }
    }

    //Ativa o pino s11 se o nível do tanque for maior ou igual a 10
    pin_s11 = (tank1 >= 10);
    //Ativa o pino s22 se o nível de tanque for maior ou igual a 90
    pin_s12 = (tank1 >= 90);

    // Para teste... Vazamento/consumo
    if(tank1 >= 0.01){
        tank1 -= 0.01;
    }

    //Verifica se a bomba está ativa e adiciona no tanque 2
    if(pin_bomb) {
        tank2 += 0.1;
        tank1 -= 0.1;

        if(tank2 > 100) {
            tank2 = 100;
        }
    }

    //Teste de vazamento do tanque2
    if(tank2 >= 0.01) {
        tank2 -= 0.01;
    }

    //Ativa o pino s21 se o nível do tanque2 for maior ou igual a 10
    pin_s21 = (tank2 >= 10);
    //Ativa o pino s22 se o nível do tanque2 for maior ou igual a 90
    pin_s22 = (tank2 >= 90);
}
