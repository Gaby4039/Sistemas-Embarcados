#include "../common/hal.h"
#include<time.h>

// Define o estado dos pinos
bool pin_s11=false;
bool pin_s12=false;
bool pin_v1=true;
bool pin_sm1_error=false;
bool pin_s21 = false;
bool pin_s22 = false;
bool pin_bomb = false;


//Inicializa o hal
void init_hal(){
    pin_s11 = false;
    pin_s12 = false;
    pin_v1 = false;
    pin_s21 = false;
    pin_s22 = false;
    pin_bomb = false;
}

//Retorna a hora atual
uint32_t now(){
    return clock();
}

//Lê o pino do sensor s11
bool get_s11(){
    return pin_s11;
}

//Lê o pino do sensor s12
bool get_s12(){
    return pin_s12;
}

//Verifica o estado da válvula
void set_v1(bool state){
    pin_v1 = state;
}

//Verifica erro
void set_sm1_error(bool state){
    pin_sm1_error = state;
}

// Lê o pino do sensor s21
bool get_s21() {
    return pin_s21;
}

// Lê o pino do sensor s22
bool get_s22() {
    return pin_s22;
}

//Verifica o estado da bomba
void set_bomb(bool state) {
    pin_bomb = state;
}

