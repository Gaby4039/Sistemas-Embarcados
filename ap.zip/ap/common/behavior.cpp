#include "behavior.h"
#include "hal.h"
#include "sm1.h"

void behavior(){
    init_hal();

    StateMachine sm1;
    INIT(sm1, sm1_init);

    while(true){
        EXEC(sm1);
    }
}
