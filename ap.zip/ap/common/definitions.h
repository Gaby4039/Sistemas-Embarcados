#ifndef DEFINITIONS_H
#define DEFINITIONS_H

#define SM1_TIMER   3000

#endif // DEFINITIONS_H
