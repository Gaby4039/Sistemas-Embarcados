#ifndef DEFINITIONS_H
#define DEFINITIONS_H

//Define o timer de cada máquina de estado
#define SM1_TIMER   3000
#define SM2_TIMER   3000

#endif // DEFINITIONS_H
