#pragma once
#include<stdint.h>

typedef uint32_t chronometer;

void chrono_start(chronometer *c, uint32_t delta_t_ms);
bool chrono_is_finished(chronometer *c);
