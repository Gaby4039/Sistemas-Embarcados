#include "sm1.h"
#include "hal.h"
#include "definitions.h"
#include "chronometer.h"

//Chama o cronômetro da máquina de estados 1
chronometer sm1_chrono;

//Define que, ao iniciar, a válvula e o indicador de erro iniciam desligados
STATE(sm1_init){
    if(ENTRY){
        set_v1(false);
        set_sm1_error(false);
    }

    //Verifica se o led s12 está ativo e se o led s11 também e vai para o estado da válvula desligada. Caso contrário, aciona o led de erro. Se o led s12 estiver inativo, liga a válvula v1
    if(get_s12()){
        if(get_s11()){
            NEXT_STATE(sm1_v1_desligada);
        } else {
            NEXT_STATE(sm1_erro);
        }
    }else{
        NEXT_STATE(sm1_v1_ligada);
    }
}

//Define que, se o estado atual é de ativação da válvula, ativa v1 e define o erro como falso. Se o led s12 estiver ligado e o led s11 também, vai para o estado da válvula desligada. Caso s11 esteja desligada e s12 ligada, ativa o led de erro
STATE(sm1_v1_ligada){
    if(ENTRY){
        set_v1(true);
        set_sm1_error(false);
    }

    if(get_s12()){
        if(get_s11()){
            NEXT_STATE(sm1_v1_desligada);
        } else{
            NEXT_STATE(sm1_erro);
        }
    }
}

//Define o estado atual como desativação da vávula, desliga v1, define o erro como falso e inicia o cronômetro. Se s12 estiver ativada e s11 desligada
STATE(sm1_v1_desligada){
    if(ENTRY){
        set_v1(false);
        set_sm1_error(false);
        chrono_start(&sm1_chrono, SM1_TIMER);
    }

    if(get_s12()){
        if(!get_s11()){
            NEXT_STATE(sm1_erro);
        }
    } else {
        if(chrono_is_finished(&sm1_chrono)){
            NEXT_STATE(sm1_v1_ligada);
        }
    }
}

STATE(sm1_erro){
    if(ENTRY){
        set_v1(false);
        set_sm1_error(true);
    }
}
