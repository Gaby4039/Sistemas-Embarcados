#include "sm1.h"
#include "hal.h"
#include "definitions.h"
#include "chronometer.h"

chronometer sm1_chrono;

STATE(sm1_init){
    if(ENTRY){
        set_v1(false);
        set_sm1_error(false);
    }

    if(get_s12()){
        if(get_s11()){
            NEXT_STATE(sm1_v1_desligada);
        } else {
            NEXT_STATE(sm1_erro);
        }
    }else{
        NEXT_STATE(sm1_v1_ligada);
    }
}

STATE(sm1_v1_ligada){
    if(ENTRY){
        set_v1(true);
        set_sm1_error(false);
    }

    if(get_s12()){
        if(get_s11()){
            NEXT_STATE(sm1_v1_desligada);
        } else{
            NEXT_STATE(sm1_erro);
        }
    }
}

STATE(sm1_v1_desligada){
    if(ENTRY){
        set_v1(false);
        set_sm1_error(false);
        chrono_start(&sm1_chrono, SM1_TIMER);
    }

    if(get_s12()){
        if(!get_s11()){
            NEXT_STATE(sm1_erro);
        }
    } else {
        if(chrono_is_finished(&sm1_chrono)){
            NEXT_STATE(sm1_v1_ligada);
        }
    }
}

STATE(sm1_erro){
    if(ENTRY){
        set_v1(false);
        set_sm1_error(true);
    }
}
