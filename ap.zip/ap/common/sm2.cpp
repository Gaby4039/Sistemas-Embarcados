#include "sm2.h"
#include "../common/hal.h"
#include "../common/definitions.h"
#include "chronometer.h"

chronometer sm2_chrono;

STATE(sm2_init){
    if(ENTRY){
        set_bomb(false);
        set_sm2_error(false);
    }

    if(get_s22()){
        if(get_s21()){
            NEXT_STATE(sm2_bomb_desligada);
        } else {
            NEXT_STATE(sm2_erro);
        }
    }else{
        NEXT_STATE(sm2_bomb_ligada);
    }
}

STATE(sm2_bomb_ligada){
    if(ENTRY){
        set_bomb(true);
        set_sm2_error(false);
    }

    if(get_s22()){
        if(get_s21()){
            NEXT_STATE(sm2_bomb_desligada);
        } else{
            NEXT_STATE(sm2_erro);
        }
    }
}

STATE(sm2_bomb_desligada){
    if(ENTRY){
        set_bomb(false);
        set_sm2_error(false);
        chrono_start(&sm2_chrono, SM2_TIMER);
    }

    if(get_s22()){
        if(!get_s21()){
            NEXT_STATE(sm2_erro);
        }
    } else {
        if(chrono_is_finished(&sm2_chrono)){
            NEXT_STATE(sm2_bomb_ligada);
        }
    }
}

STATE(sm2_erro){
    if(ENTRY){
        set_bomb(false);
        set_sm2_error(true);
    }
}
