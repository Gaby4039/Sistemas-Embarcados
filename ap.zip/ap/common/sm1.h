#ifndef SM1_H
#define SM1_H

#include "sm.h"

STATE(sm1_init);
STATE(sm1_v1_ligada);
STATE(sm1_v1_desligada);
STATE(sm1_erro);

#endif // SM1_H
