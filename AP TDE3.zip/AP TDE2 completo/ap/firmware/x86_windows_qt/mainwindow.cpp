#include "mainwindow.h"
#include "ui_mainwindow.h"

double tank1 = 0.0;
double tank2 = 0.0;
double tank3 = 0.0;
bool consumption_t3 = false;
double flow_rate = 0.3;
double consumption = 0.05;
int scenario_consumption = 1;
char scenario_validation = 'E';
bool start_consumption = false;
bool start_validation = true;
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(&update_ui_timer,
            &QTimer::timeout,
            this,
            &MainWindow::update_ui);
    update_ui_timer.start(33); // 3x por segundo
    connect(&physical_behavior_timer,
            &QTimer::timeout,
            this,
            &MainWindow::physical_behavior);
    physical_behavior_timer.start(10); // 100x por segundo
    thread_behavior.start();
}

MainWindow::~MainWindow()
{
    delete ui;
}

extern bool pin_v1;
extern bool pin_s11;
extern bool pin_s12;
extern bool pin_sm1_error;
extern bool pin_b1;
extern bool pin_s21;
extern bool pin_s22;
extern bool pin_sm2_error;
extern bool pin_v2;
extern bool pin_s31;
extern bool pin_s32;
extern bool pin_sm3_error;
extern bool pin_r1;
extern float pin_st1;
//extern const char* sm1_state_str;
//extern const char* sm2_state_str;
//extern const char* sm3_state_str;
//extern const char* sm4_state_str;

void MainWindow::update_ui(){
    ui->toolButton_v1->setPower(pin_v1);
    ui->toolButton_s11->setPower(pin_s11);
    ui->toolButton_s12->setPower(pin_s12);
    ui->toolButton_sm1_error->setPower(pin_sm1_error);
    ui->toolButton_t1->setValue(tank1);
    ui->toolButton_t1_overflow->setPower(tank1 > 1000.0);
    ui->toolButton_b1->setPower(pin_b1);
    ui->toolButton_s21->setPower(pin_s21);
    ui->toolButton_s22->setPower(pin_s22);
    ui->toolButton_sm2_error->setPower(pin_sm2_error);
    ui->toolButton_t2->setValue(tank2);
    ui->toolButton_t2_overflow->setPower(tank2 > 1000.0);
    ui->toolButton_v2->setPower(pin_v2);
    ui->toolButton_s31->setPower(pin_s31);
    ui->toolButton_s32->setPower(pin_s32);
    ui->toolButton_t3->setValue(tank3);
    ui->toolButton_t3->MaxValue = 250.0;
    ui->toolButton_t3_overflow->setPower(tank3 > 250.0);
    ui->toolButton_sm3_error->setPower(pin_sm3_error);
    ui->toolButton_r1->setPower(pin_r1);
    ui->progressBar_temp->setValue(pin_st1);
    ui->lcdNumber_temp->display(QString::number(pin_st1, 'f', 1));
    //ui->label_sm3->setText(sm3_state_str);
    //ui->label_sm4->setText(sm4_state_str);

    if(pin_st1 < 49.0) {
        ui->progressBar_temp->setStyleSheet(
            "QProgressBar::chunk { background-color: blue; }"
            );
    }
    else if(pin_st1 <= 51.0) {
        ui->progressBar_temp->setStyleSheet(
            "QProgressBar::chunk { background-color: green; }"
            );
    }
    else {
        ui->progressBar_temp->setStyleSheet(
            "QProgressBar::chunk { background-color: red; }"
            );
    }

}

void MainWindow::physical_behavior(){
    if(start_consumption) {
        switch(scenario_consumption) {
        case 1: // Consumo igual à vazão
            flow_rate = 1;
            consumption = 1;
            break;
        case 2: // Consumo maior que a vazão
            flow_rate = 1;
            consumption = 2;
            break;
        case 3: // Consumo menor que a vazão
            flow_rate = 2;
            consumption = 1;
            break;
        }
    }

    //Testes
    if(start_validation) {
        switch(scenario_validation) {
        case 'A':
            tank1 = 0.0;
            tank2 = 1000.0;
            tank3 = 0.0;
            pin_st1 = 25.0;
            break;

        case 'B':
            tank2 = 500.0;
            tank3 = 0.0;
            pin_st1 = 25.0;
            break;

        case 'C':
            tank2 = 0.0;
            tank3 = 250.0;
            pin_st1 = 25.0;
            break;

        case 'D':
            tank2 = 100.0;
            tank3 = 222.5;
            pin_st1 = 25.0;
            break;

        case 'E':
            tank2 = 0.0;
            tank3 = 250.0;
            pin_st1 = 50.0;
            consumption_t3 = true;
            break;
        }
        pin_b1 = false;
        pin_v1 = false;

        start_validation = false;
    }

    // Quando a válvula está ligada, adiciona 1l ao tank1
    if(pin_v1){
        //tank1 += flow_rate;

        // Evita overflow tank1
        if(tank1 > 1000.0) {
            tank1 = 1000.0;
        }

        if(tank1 < 0.0)
            tank1 = 0.0;
    }

    // Quando a bomba está ligada e o tanque não está vazio, o tank2 recebe a água do tank1
    if(pin_b1) {
        tank2 += flow_rate;
        tank1 -= consumption;

        // Evita overflow tank2
        if(tank2 > 1000.0) {
            tank2 = 1000.0;
        }

        if(tank2 < 0.0)
            tank2 = 0.0;
    }

    //TDE2

    if(pin_v2) {
        double h_t2 = tank2;
        double h_t3 = tank3 * 2;

        if(h_t2 > h_t3) {
            tank3 += flow_rate;
            tank2 -= flow_rate;
        }
        else if(h_t2 < h_t3) {
            tank2 += flow_rate;
            tank3 -= flow_rate;
        }

        if(tank3 > 250.0) {
            tank3 = 250.0;
        }

        if(tank2 > 1000.0) {
            tank2 = 1000.0;
        }

        if(tank2 < 0.0) {
            tank2 = 0.0;
        }

        if(tank3 < 0.0) {
            tank3 = 0.0;
        }
    }

    // Simulação consumo tank3
    if(consumption_t3) {
        tank3 -= consumption;

        if(tank3 < 0.0) {
            tank3 = 0.0;
        }
    }

    // Controle de temperatura
    if(pin_r1) {
        pin_st1 += 0.02;
    }
    else {
        pin_st1 -= 0.005;
    }

    if(pin_st1 > 100.0) {
        pin_st1 = 100.0;
    }

    if(pin_st1 < 0.0) {
        pin_st1 = 0.0;
    }

    pin_s11 = (tank1 >= 100.0);
    pin_s12 = (tank1 >= 900.0);

    pin_s21 = (tank2 >= 100.0);
    pin_s22 = (tank2 >= 900.0);

    pin_s31 = (tank3 >= 25.0);
    pin_s32 = (tank3 >= 225.0);

    qDebug()
        << "Tank1: " << tank1
        << "Tank2: " << tank2
        << "Tank3: " << tank3;
}


