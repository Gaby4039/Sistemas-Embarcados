/*
 * hal.cpp
 *
 * Created: 06/05/2026 17:45:33
 *  Author: p.gabrielly
 */ 

void init_hal() {
	pinMode(2, INPUT);
	pinMode(3, INPUT);
	pinMode(4, INPUT);
	pinMode(5, INPUT);
	pinMode(6, INPUT);
	pinMode(7, OUTPUT);
	pinMode(8, OUTPUT);
	pinMode(9, OUTPUT);
	pinMode(10, OUTPUT);
	pinMode(11, OUTPUT);
	pinMode(A0, analogRead(A0));
	
	bool status_s11 = digitalRead(2);
	bool status_s12 = digitalRead(3);
	bool status_s21 = digitalRead(4);
	bool status_s22 = digitalRead(5);
	bool status_s31 = digitalRead(6);
	bool status_s32 = digitalRead(7);
	bool status_v1 = digitalWrite(8);
	bool status_v2 = digitalWrite(9);
	bool status_b1 = digitalWrite(10);
	bool status_r1 = digitalWrite(11);
	bool status_st1 = analogRead(A0);
	
	float lerTemperatura() {
		int ValorLido = analogRead(A0);
		float temperatura = 40.0 + (ValorLido / 1023.0) * (60.0 - 40.0);
		return temperatura;
	}
}

