#include "mainwindow.h"
#include "ui_mainwindow.h"

double tank1 = 100.0;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(&update_ui_timer,
            &QTimer::timeout,
            this,
            &MainWindow::update_ui);
    update_ui_timer.start(33); // 3x por segundo
    connect(&physical_behavior_timer,
            &QTimer::timeout,
            this,
            &MainWindow::physical_behavior);
    physical_behavior_timer.start(10); // 100x por segundo
    thread_behavior.start();
}

MainWindow::~MainWindow()
{
    delete ui;
}

extern bool pin_v1;
extern bool pin_s11;
extern bool pin_s12;
extern bool pin_sm1_error;

void MainWindow::update_ui(){
    ui->toolButton_v1->setPower(pin_v1);
    ui->toolButton_s11->setPower(pin_s11);
    ui->toolButton_s12->setPower(pin_s12);
    ui->toolButton_sm1_error->setPower(pin_sm1_error);
    ui->toolButton_t1->setValue(tank1);
    ui->toolButton_overflow->setPower(tank1 >= 100);
}

void MainWindow::physical_behavior(){
    if(pin_v1){
        tank1 += 0.1;
        if(tank1 > 100){
            tank1 = 100;
        }
    }
    pin_s11 = (tank1 >= 10);
    pin_s12 = (tank1 >= 90);

    // Para teste... Vazamento/consumo
    if(tank1 >= 0.01){
        tank1 -= 0.01;
    }
}
