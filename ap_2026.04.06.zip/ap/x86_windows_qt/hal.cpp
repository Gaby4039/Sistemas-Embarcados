#include "../common/hal.h"
#include<time.h>

bool pin_s11=false;
bool pin_s12=false;
bool pin_v1=true;
bool pin_sm1_error=false;

void init_hal(){
    pin_s11 = false;
    pin_s12 = false;
    pin_v1 = false;
}

uint32_t now(){
    return clock();
}

bool get_s11(){
    return pin_s11;
}

bool get_s12(){
    return pin_s12;
}

void set_v1(bool state){
    pin_v1 = state;
}

void set_sm1_error(bool state){
    pin_sm1_error = state;
}
