#ifndef HAL_H
#define HAL_H
#include<stdint.h>

void init_hal();
uint32_t now();
bool get_s11();
bool get_s12();
void set_v1(bool state);

// LEds indicators
void set_sm1_error(bool state);

#endif // HAL_H
