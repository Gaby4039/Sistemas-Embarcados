#include "../../common/hal.h"
#include<stdio.h>
#include<windows.h>

void init_hal() {

}

void set_led(bool state) {
	if (state) {
		printf("1\n");
	}else {
		printf("0\n");
	}
}

void pause(uint32_t ms) {
	Sleep(ms);
}
