#include "behavior.h"

void behavior() {
	init_hal();
	while (1) {
		set_led(true);	// Liga LED
		pause(100);
		set_led(false); // Apaga o LED
		pause(100);
	}
}

