#ifndef __HAL_H__
#define __HAL_H__

#include <stdint.h>

void init_hal();
void set_led(bool state);
void pause(uint32_t ms);

#endif
