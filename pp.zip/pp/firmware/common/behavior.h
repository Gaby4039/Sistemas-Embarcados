#include "hal.h"

void behavior();