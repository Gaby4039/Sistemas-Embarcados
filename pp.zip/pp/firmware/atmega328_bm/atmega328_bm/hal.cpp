﻿#include "../../common/hal.h"
#define F_CPU 16000000
#include<util/delay.h>
#include <avr/io.h>

void init_hal(){
	DDRB = 0b00100000;
}

void set_led(bool state){
	if(state){
		PORTB = 0b00100000;
	}else{
		PORTB = 0b00000000;
	}
}

void pause(uint32_t ms){
	for(uint32_t cont=0;cont<ms;cont++)
		_delay_ms(1);
}