#include "../common/sm3.h"
#include "../common/hal.h"
#include "../common/definitions.h"
#include "../common/chronometer.h"

chronometer sm3_chrono;

STATE(sm3_init) {
    if(ENTRY) {
        set_v2(false);
        set_sm3_error(false);
        //sm3_state_str = "sm3_init";
    }


    if(get_s32()) {
        if(!get_s31()) {
            NEXT_STATE(sm3_erro);
        }
        else {
            NEXT_STATE(sm3_v2_desligada);
        }
    }
    else {
        if(get_s21()) {
            NEXT_STATE(sm3_v2_ligada);
        }
        else {
            NEXT_STATE(sm3_v2_desligada);
        }
    }
}

STATE(sm3_v2_ligada) {
    if(ENTRY) {
        set_v2(true);
        set_sm3_error(false);
        //sm3_state_str = "sm3_v2_ligada";
    }

    if(get_s32()) {
        if(!get_s31()) {
            NEXT_STATE(sm3_erro);
        }
        else {
            NEXT_STATE(sm3_v2_desligada);
        }
    }
    else if(!get_s21()) {
        NEXT_STATE(sm3_v2_desligada);
    }
}

STATE(sm3_v2_desligada) {
    if(ENTRY) {
        set_v2(false);
        set_sm3_error(false);
        //sm3_state_str = "sm3_v2_desligada";
    }

    if(!get_s32()) {
        if(get_s21()) {
            NEXT_STATE(sm3_v2_ligada);
        }
    }
    else if(get_s32()) {
        if(!get_s31()) {
            NEXT_STATE(sm3_erro);
        }
    }
}

STATE(sm3_erro) {
    if(ENTRY) {
        set_v2(false);
        set_sm3_error(true);
        //sm3_state_str = "sm3_erro";
    }
}

